# SK Bike Clinic website starter

Includes a customer website (`/`), booking form, WhatsApp link, and separate owner dashboard (`/admin`) for booking and payment statuses.

## Test locally on Windows
1. Install Node.js LTS from https://nodejs.org
2. Extract this ZIP.
3. Open Command Prompt in the extracted folder.
4. Run `npm install`
5. Set a private PIN: Command Prompt: `set OWNER_PIN=your-private-long-pin` ; PowerShell: `$env:OWNER_PIN="your-private-long-pin"`
6. Run `npm start`
7. Visit `http://localhost:3000` for customers and `http://localhost:3000/admin` for your dashboard.

## Publish online (Render example)
1. Put these files in a private GitHub repository (ask a parent/guardian to help if account age rules apply).
2. Create a Render Web Service connected to that repository.
3. Build command: `npm install`; Start command: `npm start`.
4. Add environment variable `OWNER_PIN` with a strong private value.
5. Deploy and test the public URL. Dashboard path is `/admin`.
Official instructions: https://render.com/docs/web-services

## Important before real bookings
This starter stores data in a JSON file. Some hosts have temporary filesystems, so bookings may be lost after redeploy/restart. Before relying on it for customers, connect persistent database/storage, set up backups and rate limiting, and review privacy requirements. Never share the owner PIN. Free hosting can sleep and has limitations; check current terms. A custom domain can be connected later.

Business details: SK Bike Clinic, Meadowlands Zone 6, Soweto. WhatsApp 076 789 3412.
Reference prices: rims R250 each, long steering R320, spray R50 per can, assembly labour R50. Confirm final quotes before work starts.
