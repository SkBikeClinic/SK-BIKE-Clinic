const express=require("express"),fs=require("fs"),path=require("path"),crypto=require("crypto");
const app=express(),PORT=process.env.PORT||3000,OWNER_PIN=process.env.OWNER_PIN;
if(!OWNER_PIN) console.warn("Set OWNER_PIN in hosting environment before use.");
const DATA_DIR=process.env.DATA_DIR||path.join(__dirname,"data"),DB=path.join(DATA_DIR,"bookings.json");
fs.mkdirSync(DATA_DIR,{recursive:true});if(!fs.existsSync(DB))fs.writeFileSync(DB,"[]");
app.use(express.json({limit:"40kb"}));app.use(express.static(path.join(__dirname,"public")));
function read(){try{return JSON.parse(fs.readFileSync(DB,"utf8"))}catch{return []}}
function write(x){fs.writeFileSync(DB,JSON.stringify(x,null,2))}
function owner(req,res,next){const a=Buffer.from(req.get("x-owner-pin")||""),b=Buffer.from(OWNER_PIN||"unset");if(!OWNER_PIN||a.length!==b.length||!crypto.timingSafeEqual(a,b))return res.status(401).json({error:"Owner login failed. Check the PIN."});next()}
app.get("/api/health",(_,r)=>r.json({ok:true}));
app.post("/api/bookings",(q,r)=>{for(const f of ["name","phone","bike","service","date"])if(!String(q.body[f]||"").trim())return r.status(400).json({error:`Please complete ${f}.`});
const b={id:crypto.randomUUID(),createdAt:new Date().toISOString(),name:String(q.body.name).trim().slice(0,100),phone:String(q.body.phone).trim().slice(0,40),bike:String(q.body.bike).trim().slice(0,120),service:String(q.body.service).trim().slice(0,120),date:String(q.body.date).slice(0,30),notes:String(q.body.notes||"").trim().slice(0,1000),paymentStatus:"Not recorded",status:"Pending"};const a=read();a.unshift(b);write(a);r.status(201).json({ok:true,id:b.id})});
app.get("/api/bookings",owner,(_,r)=>r.json(read()));
app.patch("/api/bookings/:id",owner,(q,r)=>{const statuses=["Pending","Confirmed","In Progress","Completed","Cancelled"],payments=["Not recorded","Unpaid","Deposit paid","Paid"],a=read(),b=a.find(x=>x.id===q.params.id);if(!b)return r.status(404).json({error:"Booking not found"});if(statuses.includes(q.body.status))b.status=q.body.status;if(payments.includes(q.body.paymentStatus))b.paymentStatus=q.body.paymentStatus;write(a);r.json({ok:true,booking:b})});
app.get("/admin",(_,r)=>r.sendFile(path.join(__dirname,"public","owner.html")));
app.listen(PORT,"0.0.0.0",()=>console.log("SK Bike Clinic running on "+PORT));